var listeneradded = false;
var timeout = null;
$(document).ready(function() {
    $(document).ajaxSend(function (event, request, settings) {
        request.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    });

	$(".js-include").each(function(){
        var inc=$(this);
        if (typeof $("#header")[0]!="undefined") {
        	return;
        }
        $.get(inc.attr("title"), function(data){
            inc.replaceWith(data);
            
            var headerLink = document.getElementsByClassName("headerlink");
        	for (var i=0;i<headerLink.length;i++) {
        		$(headerLink[i]).bind("click",linkClicked);
                var link_local_part = $(headerLink[i]).attr("href").split("?");
                var link_page_name = link_local_part[1].split("=")[1];
				
                var current_local_part = location.href.split("?");
				var current_page_name = current_local_part[1].split("=")[1];
           
                /*if (current_page_name=="index") {
                    if (!$("#map").length) {
                        $("#content").append("<img id=\"map\" src=\"images/kontuurkaart.jpg\" alt=\"kaart\" />");
                    }
                    continue;
                }*/
				var page_name_with_removed_params = current_page_name.split("&");
                if (link_page_name==page_name_with_removed_params[0]) {
                    $(headerLink[i]).trigger("click",location.href);
                }
        	}
			generateloginbox();
        });
    });
	window.addEventListener('popstate', function(event) {
		console.log('popstate fired!');
		var filename = event.target.location.href;
		var current_local_part = "";
		if (filename!="") {
			current_local_part = filename.split("?")[1];
			filename = getFileNameByPageParam(current_local_part.split(/=|&/)[1]);
		}
		updateContent(event.state, filename, current_local_part); 
		clearTimeout(timeout);
		timeout = setTimeout(function() {}, 50);
	});
});
function linkClicked(event,params) {
	event.preventDefault();
	if (typeof params!= 'undefined') {
		event.target.href = params;
	}
	navigation(event);
	
	return false;
}
function generateloginbox() {
	$("#login").hover(function() {
		$("#loginform").toggle();
	});
	$.getJSON('/server/VerifyLogin', function(data) {
		$("#logform").empty();
		if (data.result=="success") {
			var form = '<form action="/server/VerifyLogin" id="loginform" method="post" accept-charset="utf-8">'
				 + '<div id="namefield" style="text-transform:capitalize;"> Nimi: <b>'+data.username+'</b></div>'
				 + '<input type="submit" name="Submit" value="Logi Välja"><br/>' 
				 + '</form>';
			$("#logform").append(form);
			$("#loginform").submit(function(event) {
				event.preventDefault();
				$.post("/server/VerifyLogin", { "logout": 5433 }, function(data) {
					window.location.reload();
				});
			});
		} else {
			var form = '<form action="/server/VerifyLogin" id="loginform" method="post" accept-charset="utf-8">'
					 + '<label for="username">Kasutajanimi: </label>'
					 + '<input type="text" name="username" id="username"/><br/>'
					 + '<label for="password">Parool: </label>'  
					 + '<input type="password" name="userpass" id="userpass"/><br/>'
					 + '<label for="key">Registreerimisvõti: </label>'
					 + '<input type="text" name="key" id="key"/><br/>'
					 + '<input type="submit" name="Submit" value="Meldi"><br/>' 
					 + '</form>';
			$("#logform").append(form);
			$("#loginform").submit(function(event) {
				event.preventDefault();
				//
				var username = $("#username").val();
				var password = $("#userpass").val();
				var registry_key = $("#key").val();
				if (registry_key.length==0) {
					var request = { "username": username, "password": password };		
				} else {
					var request = { "username": username, "password": password,"key":registry_key };
				}
				$.post("/server/VerifyLogin", request, function(data) {
					if (data.result=="success") {
						window.location.reload();
					} else {
						alert(data.error_code);
					}
				});
			});
		}
	});
}
