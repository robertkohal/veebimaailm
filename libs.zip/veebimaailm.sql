-- MySQL dump 10.13  Distrib 5.5.30, for Linux (x86_64)
--
-- Host: localhost    Database: veebimaailm
-- ------------------------------------------------------
-- Server version	5.5.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidate`
--
DROP DATABASE IF EXISTS `veebimaailm`;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `veebimaailm` /*!40100 DEFAULT CHARACTER SET latin1 */;

--
--DELETE FROM user WHERE user= 'veebimaailmAdmin';

--CREATE USER 'veebimaailmAdmin'@'%' IDENTIFIED BY PASSWORD '3Qnsk0ZBhtXSHzQwdkDp';

--GRANT ALL PRIVILEGES ON * . * TO 'veebimaailmAdmin'@'%';
GRANT ALL ON veebimaailm.* TO 'veebimaailmAdmin'@'localhost' IDENTIFIED BY'3Qnsk0ZBhtXSHzQwdkDp';

FLUSH PRIVILEGES;

USE `veebimaailm`;    

DROP TABLE IF EXISTS `candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidate` (
  `id_candidate` int(11) NOT NULL AUTO_INCREMENT,
  `id_party` int(11) NOT NULL,
  `id_region` int(11) NOT NULL,
  `id_person` int(11) NOT NULL,
  PRIMARY KEY (`id_candidate`),
  KEY `candidate_party` (`id_party`),
  KEY `candidate_region` (`id_region`),
  KEY `candidate_person` (`id_person`),
  CONSTRAINT `candidate_party` FOREIGN KEY (`id_party`) REFERENCES `party` (`id_party`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `candidate_person` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `candidate_region` FOREIGN KEY (`id_region`) REFERENCES `region` (`id_region`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate`
--

LOCK TABLES `candidate` WRITE;
/*!40000 ALTER TABLE `candidate` DISABLE KEYS */;
INSERT INTO `candidate` VALUES (1,2,11,1),(2,1,6,2),(3,4,3,3),(4,3,6,4),(5,4,8,5),(6,2,8,6),(7,1,8,10),(8,3,8,11),(9,1,3,7),(10,4,8,8),(11,2,13,9),(12,3,8,15),(13,1,13,16),(14,4,4,17),(15,1,3,18),(16,2,6,19),(17,4,7,20),(18,3,5,21),(19,2,7,22),(20,4,6,25),(30,3,5,32);
/*!40000 ALTER TABLE `candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `id_party` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id_party`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party`
--

LOCK TABLES `party` WRITE;
/*!40000 ALTER TABLE `party` DISABLE KEYS */;
INSERT INTO `party` VALUES (1,'Eesti Keskerakond'),(2,'Eesti Reformierakond'),(3,'Isamaa- ja Respublica Liit'),(4,'Sotsiaaldemokraatlik erakond');
/*!40000 ALTER TABLE `party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id_person` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `password` varchar(129) DEFAULT NULL,
  `salt` varchar(60) DEFAULT NULL,
  `ssn` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_person`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'Eduard','Ekskavaator',NULL,NULL,NULL),(2,'Ferdinand','Fuksia',NULL,NULL,NULL),(3,'Gerhard','Gätegõverdus',NULL,NULL,NULL),(4,'Harald','Hamster',NULL,NULL,NULL),(5,'Ildegaard','Ilumeel',NULL,NULL,NULL),(6,'Janaida','Jalutova',NULL,NULL,NULL),(7,'Magdalena','Malejeva',NULL,NULL,NULL),(8,'Neeme','Näljahäda',NULL,NULL,NULL),(9,'Olga','Oravasaba',NULL,NULL,NULL),(10,'Kõikme','Kannatameära',NULL,NULL,NULL),(11,'Leila','Lagerfeld',NULL,NULL,NULL),(12,'Mikk','Valija',NULL,NULL,NULL),(13,'Henri','Hääletaja',NULL,NULL,NULL),(14,'Robert','Kandidaat',NULL,NULL,NULL),(15,'Anna','Eksootika',NULL,NULL,NULL),(16,'Kati','Kood',NULL,NULL,NULL),(17,'Mati','Simpel',NULL,NULL,NULL),(18,'Mari','Ärtu',NULL,NULL,NULL),(19,'Karl','Gustav',NULL,NULL,NULL),(20,'Peter','Kujur',NULL,NULL,NULL),(21,'Ülle','Ühik',NULL,NULL,NULL),(22,'Riho','Herilane',NULL,NULL,NULL),(25,'niki','Valija','109890b81676ab45b6c96749fcf71a4aaa6c3f39ea9a5cf8b32eef5da958643ff38a66f6686319aa32cef8c229e0974214d155f3e4504a2b865bf776e3509f5b','OlzciIAO/[iU0F\"$wN!K[zh(J(Im]Mzl',NULL),(29,'Samba','Soo','df4547be882cbc546098039c6a9f1047ee599c1c9b8ca785558b4958845e205a01faf5fa34dd5e14ae13deced70697e8cd233158d451b0273f0f92fa6790a15f','B<xuR?DGx%BEz=L9\\u96WD5j{#}Q*E>:',NULL);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id_region` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id_region`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'Harju maakond'),(2,'Hiiu maakond'),(3,'Ida-Viru maakond'),(4,'Jõgeva maakond'),(5,'Järve maakond'),(6,'Lääne maakond'),(7,'Lääne-Viru maakond'),(8,'Põlva maakond'),(9,'Pärnu maakond'),(10,'Rapla maakond'),(11,'Saare maakond'),(12,'Tallinn'),(13,'Tartu'),(14,'Tartu maakond'),(15,'Valga maakond'),(16,'Viljandi maakond'),(17,'Võru maakond');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vote`
--

DROP TABLE IF EXISTS `vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vote` (
  `id_vote` int(11) NOT NULL AUTO_INCREMENT,
  `id_candidate` int(11) DEFAULT NULL,
  `id_person` int(11) DEFAULT NULL,
  `vote_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_vote`),
  UNIQUE KEY `id_person_UNIQUE` (`id_person`),
  KEY `vote_candidate` (`id_candidate`),
  KEY `vote_person` (`id_person`),
  CONSTRAINT `vote_candidate` FOREIGN KEY (`id_candidate`) REFERENCES `candidate` (`id_candidate`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `vote_person` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vote`
--

LOCK TABLES `vote` WRITE;
/*!40000 ALTER TABLE `vote` DISABLE KEYS */;
INSERT INTO `vote` VALUES (1,4,1,'2013-03-24 15:42:33'),(2,6,2,'2013-03-24 15:42:33'),(3,4,3,'2013-03-24 15:42:33'),(4,8,4,'2013-03-24 15:42:33'),(5,12,5,'2013-03-24 15:42:33'),(6,8,6,'2013-03-24 15:42:33'),(7,9,7,'2013-03-24 15:42:33'),(8,7,8,'2013-03-24 15:42:33'),(9,13,9,'2013-03-24 15:42:33'),(10,16,10,'2013-03-24 15:42:33'),(11,4,11,'2013-03-24 15:42:33'),(13,13,13,'2013-03-24 15:42:33'),(14,16,14,'2013-03-24 15:42:33'),(15,5,15,'2013-03-24 15:42:33'),(16,8,16,'2013-03-24 15:42:33'),(17,1,17,'2013-03-24 15:42:33'),(18,5,18,'2013-03-24 15:42:33'),(19,6,19,'2013-03-24 15:42:33'),(20,9,20,'2013-03-24 15:42:33'),(21,10,21,'2013-03-24 15:42:33'),(22,4,22,'2013-03-24 15:42:33'),(28,8,29,'2013-04-01 09:44:03'),(33,30,32,'2013-04-08 09:45:31');
/*!40000 ALTER TABLE `vote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-08 19:55:38
